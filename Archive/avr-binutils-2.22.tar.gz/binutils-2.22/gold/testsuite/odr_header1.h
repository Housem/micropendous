#include "odr_header2.h"

struct OdrDerived : OdrBase {
  ~OdrDerived() {
  }
};
